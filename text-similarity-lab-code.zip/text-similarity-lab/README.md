# Tcc
Comparação textual estudadas
